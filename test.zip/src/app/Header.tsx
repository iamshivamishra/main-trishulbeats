"use client";

import React, { useEffect, useState, useRef } from "react";
import Link from "next/link";
import { FaShoppingCart } from "react-icons/fa";
import "./Header.css";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const menuRef = useRef<HTMLDivElement | null>(null);

  // SCROLL DETECTION
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // CLOSE MENU WHEN CLICKING OUTSIDE
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target as Node)
      ) {
        setMenuOpen(false);
      }
    };

    if (menuOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [menuOpen]);

  return (
    <header className={`header ${isScrolled ? "scrolled" : ""}`} ref={menuRef}>
      <h1 className="logos">
        <Link href="/" className="logos">
          Trishul Beats
        </Link>
      </h1>

      {/* NAVIGATION */}
      <nav>
        <ul className={`nav-lists ${menuOpen ? "active" : ""}`}>
          <li>
            <Link href="/" className="nav-links" onClick={() => setMenuOpen(false)}>
              Home
            </Link>
          </li>
          <li>
            <Link href="/beatpacks" className="nav-links" onClick={() => setMenuOpen(false)}>
              Beat Packs
            </Link>
          </li>
          <li>
            <Link href="/contact" className="nav-links" onClick={() => setMenuOpen(false)}>
              Contact
            </Link>
          </li>
          <li>
            <Link href="/cart" className="nav-links flex-centers" onClick={() => setMenuOpen(false)}>
              <FaShoppingCart size={18} />
            </Link>
          </li>
        </ul>
      </nav>

      {/* HAMBURGER */}
      <div
        className={`hamburger ${menuOpen ? "active" : ""}`}
        onClick={() => setMenuOpen(!menuOpen)}
      >
        <span></span>
        <span></span>
        <span></span>
      </div>
    </header>
  );
}
