__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/533536ea707455e1.js",
  "static/chunks/turbopack-a24c9960353e176a.js"
])
