__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/533536ea707455e1.js",
  "static/chunks/turbopack-bd387ef4751bbc9b.js"
])
